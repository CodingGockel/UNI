public class Bauer extends Einwohner
{
    public Bauer(){
        
    }
}
