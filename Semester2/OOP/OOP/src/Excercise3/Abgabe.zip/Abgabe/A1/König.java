public class König extends Einwohner
{
    public König()
    {
        
    }
    int zuVersteuerndesEinkommen(){
        return 0;
    }
    int steuer(){
        return 0;
    }
}
